// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {
		animSpeed: 1,
		moveable: true,
        // 用于识别地图中的障碍物
        Grass: cc.TiledLayer,
		Wall: cc.TiledLayer,
		Ornament: cc.TiledLayer,
		Shelf: cc.TiledLayer,
		Camera: cc.Camera,
		// 用于记录主相机位置
		deltax: 0,
		deltay: 0,
    },
	//判断坐标是否正确
	judger(){
		console.log("judging")
		if(this.x != this.tiledTile.x || this.y != this.tiledTile.y) alert("error!");	
	},
    // LIFE-CYCLE CALLBACKS:
	dealmessage(message) {
        console.log(message.detail);
        switch(message.detail){
            case "s":
				//console.log("s");
                this.playAnim('Front');
				this.node.anchorX = 0;
				// 如果前进的方向上有障碍物，则不移动
				if( (this.Grass.tiledLayer.getTileGIDAt(this.tiledTile.x, this.tiledTile.y + 1) != 0 ) ||
				(this.Wall.tiledLayer.getTileGIDAt(this.tiledTile.x, this.tiledTile.y + 1) != 0 ) ||
				(this.Ornament.tiledLayer.getTileGIDAt(this.tiledTile.x, this.tiledTile.y + 1) != 0 ) ||
				(this.Shelf.tiledLayer.getTileGIDAt(this.tiledTile.x, this.tiledTile.y + 1) != 0 ) ){
					console.log("11111");
					break;
				}
				this.tiledTile.y += 1;
				break;
            case "w":
				//console.log("w");
                this.playAnim('Back');
				this.node.anchorX = 0;
				// 如果前进的方向上有障碍物，则不移动
				if( (this.Grass.tiledLayer.getTileGIDAt(this.tiledTile.x, this.tiledTile.y - 1) != 0 ) ||
				(this.Wall.tiledLayer.getTileGIDAt(this.tiledTile.x, this.tiledTile.y - 1) != 0 ) ||
				(this.Ornament.tiledLayer.getTileGIDAt(this.tiledTile.x, this.tiledTile.y - 1) != 0 ) ||
				(this.Shelf.tiledLayer.getTileGIDAt(this.tiledTile.x, this.tiledTile.y - 1) != 0 ) ){
					console.log("11111");
					break;
				}
				this.tiledTile.y += -1;
				break;
				
			case "a":
				//console.log("a");
				this.playAnim('Left');
				this.node.anchorX = -0.5;
				// 如果前进的方向上有障碍物，则不移动
				if( (this.Grass.tiledLayer.getTileGIDAt(this.tiledTile.x - 1, this.tiledTile.y) != 0 ) ||
				(this.Wall.tiledLayer.getTileGIDAt(this.tiledTile.x - 1, this.tiledTile.y) != 0 ) ||
				(this.Ornament.tiledLayer.getTileGIDAt(this.tiledTile.x - 1, this.tiledTile.y) != 0 ) ||
				(this.Shelf.tiledLayer.getTileGIDAt(this.tiledTile.x - 1, this.tiledTile.y) != 0 ) ){
					console.log("11111");
					break;
				}
				this.tiledTile.x += -1;
				break;
			case "d":
				//console.log("d");
				this.playAnim('Right');
				this.node.anchorX = -0.5;
				// 如果前进的方向上有障碍物，则不移动
				if( (this.Grass.tiledLayer.getTileGIDAt(this.tiledTile.x + 1, this.tiledTile.y) != 0 ) ||
				(this.Wall.tiledLayer.getTileGIDAt(this.tiledTile.x + 1, this.tiledTile.y) != 0 ) ||
				(this.Ornament.tiledLayer.getTileGIDAt(this.tiledTile.x + 1, this.tiledTile.y) != 0 ) ||
				(this.Shelf.tiledLayer.getTileGIDAt(this.tiledTile.x + 1, this.tiledTile.y) != 0 ) ){
					console.log("11111");
					break;
				}
				this.tiledTile.x += 1;
				break;	
        }
		console.log("set");		
    },
	
	playAnim(clip){
		this.pic.active = false;
		if(this.anim.getAnimationState(clip).isPlaying){
			return;
		}// 判断当前动画是否在运行，否则重新开始动画
		var animState = this.anim.play(clip);
		animState.speed = this.animSpeed;
	},
	// 停止播放，并将动画停止在第一帧
	stopAnim(){		
		var currentClip = this.anim.currentClip.name;
		this.anim.stop();
		this.anim.play(currentClip,0);
		this.anim.sample(currentClip);
		this.anim.stop();		
	},
	
    onLoad () {
		
		this.pic = this.node.getChildByName('f1');
		this.anim = this.getComponent(cc.Animation);

        // 获取tiledmap资源
        this.node.parent.parent.tiledMap = this.node.parent.parent.getComponent(cc.TiledMap);
		this.tiledTile = this.node.getComponent(cc.TiledTile);
		
        // 获取Ground层对象，用于将Tiledtile块删去以显示已经走过的效果
        this.node.parent.tiledLayer = this.node.parent.getComponent(cc.TiledLayer);
        // 获取Grass的图块信息
        this.Grass = this.node.parent.parent.getChildByName("Grass");
        this.Grass.tiledLayer = this.Grass.getComponent(cc.TiledLayer);
        // 获取Wall的图块信息
        this.Wall = this.node.parent.parent.getChildByName("Wall");
		this.Wall.tiledLayer = this.Wall.getComponent(cc.TiledLayer);
		// 获取Ornament的图块信息
        this.Ornament = this.node.parent.parent.getChildByName("Ornament");
		this.Ornament.tiledLayer = this.Ornament.getComponent(cc.TiledLayer);
		// 获取Shelf的图块信息
        this.Shelf = this.node.parent.parent.getChildByName("Shelf");
        this.Shelf.tiledLayer = this.Shelf.getComponent(cc.TiledLayer);
		console.log("Listening");
		this.node.on("move",this.dealmessage,this);
	},

    start () {

    },

    // update (dt) {},
});
