// Learn cc.Class:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/class.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/reference/attributes.html
//  - [English] http://docs.cocos2d-x.org/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - [Chinese] https://docs.cocos.com/creator/manual/zh/scripting/life-cycle-callbacks.html
//  - [English] https://www.cocos2d-x.org/docs/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

    properties: {

    },

	//产生随机数，在move()中进行方向判断
	directionGenerater(){
		return parseInt(Math.random()*4);
	},
	//向MovingMessageReceiver脚本发出移动信号
	move(){
		console.log("sending");
		this.e = new cc.Event.EventCustom("move",true);	
		switch(this.directionGenerater()){
			case 0:
				this.direction = "w";
				if(this.y == 62) break; //其他测试可注释
				this.y += -1;			//其他测试可注释
				break;
			case 1:
				this.direction = "s"
				if(this.y == 71) break;	//其他测试可注释
				this.y += 1;			//其他测试可注释
				break;
			case 2:
				this.direction = "a";
				if(this.x == 112) break;//其他测试可注释
				this.x += -1;			//其他测试可注释
				break;
			case 3:
				this.direction = "d";
				if(this.x == 120) break;//其他测试可注释
				this.x +=1;				//其他测试可注释
				break;
		}
        this.e.detail = this.direction;
		this.node.dispatchEvent(this.e,true); //发出信号
		//console.log("sent");
	},

	/* 其他测试可注释
	 * 判断坐标是否匹配*/
	judger(){
		//console.log("judging")
		if(this.x != this.tiledTile.x || this.y != this.tiledTile.y) alert("fail\n" + this.x + ":" + this.tiledTile.x + " / " + this.y + ":" + this.tiledTile.y);	
	},
	
    onLoad () {
		//cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);//用于调试
		this.tiledTile = this.node.getComponent(cc.TiledTile);
		//console.log(this.tiledTile);
		this.x = this.tiledTile.x;
		this.y = this.tiledTile.y;
		this.i = 0;
	},
	
	//用于调试
	onKeyDown(event){
		//this.move();
		//console.log(this.tiledTile.x);
		//console.log(this.x);
		
	},
		
	
    start () {
		
    },

    update (dt) {
		if(this.i < 1000){
			this.judger();	//判断坐标是否匹配
			this.move();	//人物移动
			this.i++		//测试次数，若1000次不出错则判断为Pass
		} else if(this.i == 1000){
		alert("Pass!")}	
		//assertEquals(this.x,this.tiledTile.x);
		//assertEquals(this.y,this.tiledTile.y);
	},
});
