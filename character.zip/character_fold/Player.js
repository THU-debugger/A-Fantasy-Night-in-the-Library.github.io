// Created by XIA Yuke
/* This document is to contorl the movement of player, using Keyboard;

 * UP: move upwards;
 * DOWN: move downwards;
 * LEFT: move to the left;
 * RIGHT: move to the right;
 
 * You can use two keys at the same time ;
 * When 'SHIFT' is pressed, the player will be speed up;
 */
cc.Class({
    extends: cc.Component,

    properties: {
		speed: 32, //移动速度
		blockEdge: 32, //
		animSpeed: 1,
		moveable: true
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
		//起始状态
		this.start = this.node.getChildByName('f1');
		//记录正常速度和2倍速
		this.doubleSpeed = 2 * this.speed;
		this.normalSpeed = this.speed;
		
		this.anim = this.getComponent(cc.Animation);
		
		//设置默认动作参数
		this.goDown = false;
		this.goUp = false;
		this.goLeft = false;
		this.goRight = false;
		//是否调整，用于停止时位置调整，让人物按照整数格前进
		this.adjustDown = false;
		this.adjustUp = false;
		this.adjustLeft = false;
		this.adjustRight = false;

		//开始监听
		cc.systemEvent.on(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
		cc.systemEvent.on(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
		
	},
	
	//when key is pressed;
	onKeyDown(event){
		switch(event.keyCode){
			case cc.macro.KEY.down:
				this.goDown = true;
				break;
			case cc.macro.KEY.up:
				this.goUp = true;
				break;
			case cc.macro.KEY.left:
				this.goLeft = true;
				break;
			case cc.macro.KEY.right:
				this.goRight = true;
				break;
			case cc.macro.KEY.shift:
				this.speed = this.doubleSpeed;
				//console.log(this.speed);
				break;
			default:
				break;			
		}
	},
	//when key is released;
	onKeyUp(event){
		switch(event.keyCode){
			case cc.macro.KEY.down:
				this.goDown = false;
				this.adjustDown = true;
				break;
			case cc.macro.KEY.up:
				this.goUp = false;
				this.adjustUp = true;
				break;
			case cc.macro.KEY.left:
				this.goLeft = false;
				this.adjustLeft = true;
				break;
			case cc.macro.KEY.right:
				this.goRight = false;
				this.adjustRight = true;
				break;
			case cc.macro.KEY.shift:
				this.speed = this.normalSpeed;
				//console.log(this.speed);
				break;
			default:
				break;			
		}
		if(this.keysUp()){
			this.stopAnim();
		}
	},
	
  start () {},
  
  //播放clip片段，clip：String
	playAnim(clip){
		if(this.anim.getAnimationState(clip).isPlaying){
			return;
		}//判断当前动画是否在运行，否则重新开始动画
		var animState = this.anim.play(clip);
		animState.wrapMode = cc.WrapMode.Loop;
		animState.repeatCount= 5;
		console.log("lay");
		animState.speed = this.animSpeed;
	},
	//停止播放，并将动画停止在第一帧
	stopAnim(){		
		var currentClip = this.anim.currentClip.name;
		this.anim.stop();
		this.anim.play(currentClip,0);
		this.anim.sample(currentClip);
		this.anim.stop();		
	},
	
	//判断键是否都被释放
	keysUp(){
		return !(this.goDown || this.goUp ||this.goLeft || this.goRight)
	},
	playerMove(dt){
		if(this.goDown){
			this.start.active = false;
			//move
			if(this.moveable){
				this.node.y -= this.speed * dt;
			}
			if(!this.goLeft && ! this.goRight){
				this.playAnim('Front');
			}//play animation；if UP/DOWN and RIGHT/LEFT are both pressed,'Back'/'Front' clip will not be played.
		}
		
		if(this.goUp){
			this.start.active = false;
			if(this.moveable){
				this.node.y += this.speed * dt;	
			}
			if(!this.goLeft && ! this.goRight){
				this.playAnim('Back');
			}			
		}
		
		if(this.goLeft){
			this.start.active = false;
			if(this.moveable){
				this.node.x -= this.speed * dt;
			}
			this.playAnim('Left');
		}
		
		if(this.goRight){
			this.start.active = false;
			if(this.moveable){
				this.node.x += this.speed * dt;
			}
			this.playAnim('Right');
		}
	},
	
	playerAdjust(){
		if(!this.moveable){
			return;
		}
		/*如果已经停止，则移动到下一个的格子中，并停止动画*/
		if(this.adjustUp){
			this.node.y = Math.ceil(this.node.y/this.blockEdge)*this.blockEdge;
			this.adjustUp = false;
		}
		if(this.adjustRight){
			this.node.x = Math.ceil(this.node.x/this.blockEdge)*this.blockEdge;
			this.adjustRight = false;
		}
		if(this.adjustDown){
			this.node.y = Math.floor(this.node.y/this.blockEdge)*this.blockEdge;
			this.adjustDown = false;	
		}
		if(this.adjustLeft){
			this.node.x = Math.floor(this.node.x/this.blockEdge)*this.blockEdge;
			this.adjustLeft = false;	
		}
	},
	update (dt) {
		this.playerMove(dt);
		this.playerAdjust();		
	},
	
	onDestroy () {
		//取消监听
		cc.systemEvent.off(cc.SystemEvent.EventType.KEY_DOWN, this.onKeyDown, this);
		cc.systemEvent.off(cc.SystemEvent.EventType.KEY_UP, this.onKeyUp, this);
	},
});
